# TRAVELMATE AI demo

Open `travelmate-ai.html` in a modern browser. This self-contained prototype includes a responsive dashboard, trip planner, simulated transport and hotel choices, Maya support chat, notifications, documents, profile, history, and emergency information.

All service data is mock data. It does not connect to providers, confirm real bookings, take payments, send notifications, place calls, or use live maps. The interactive planner and changes operate locally in the browser.

For production, add authenticated server APIs, a database, real provider integrations, consent and privacy controls, audit logs, validation, monitoring, and server-side secret storage. Treat provider responses as the authority for booking status; never expose API keys in the browser.
